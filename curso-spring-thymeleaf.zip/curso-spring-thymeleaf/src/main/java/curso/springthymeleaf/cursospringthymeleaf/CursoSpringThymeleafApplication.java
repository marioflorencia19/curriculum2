package curso.springthymeleaf.cursospringthymeleaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CursoSpringThymeleafApplication {

	public static void main(String[] args) {
		SpringApplication.run(CursoSpringThymeleafApplication.class, args);
	}

}
